import _rules, { createAutoCMP } from './cmps/all';

export { createAutoCMP };
export const rules = _rules;
