import generateCMPTests from "../playwright/runner";

generateCMPTests('monzo.com', [
    'https://monzo.com/us/'
]);
