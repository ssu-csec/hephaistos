import generateCMPTests from "../playwright/runner";

generateCMPTests('jquery.cookieBar', [
    'https://www.minotstateu.edu/',
    'https://www.myersbriggs.org/',
], {});
