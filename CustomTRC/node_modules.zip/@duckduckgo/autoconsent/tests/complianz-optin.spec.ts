import generateCMPTests from "../playwright/runner";

generateCMPTests('Complianz optin', [
    'https://stetson.com/',
], {
});
