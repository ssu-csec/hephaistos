import generateCMPTests from "../playwright/runner";

generateCMPTests('EZoic', [
    'https://singletrackworld.com/',
    'https://www.diyphotography.net/',
], {
    skipRegions: ['US'],
});
