import generateCMPTests from "../playwright/runner";

generateCMPTests('osano', [
    'https://www.weathertech.com/'
]);
