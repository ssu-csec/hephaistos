import generateCMPTests from "../playwright/runner";

generateCMPTests('EU Cookie Law', [
    'https://pv-magazine-usa.com/',
    'https://www.prolificliving.com/',
], {});
