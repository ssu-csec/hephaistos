import generateCMPTests from "../playwright/runner";

generateCMPTests('affinity.serif.com', [
    'https://affinity.serif.com/en-us/photo/'
]);
