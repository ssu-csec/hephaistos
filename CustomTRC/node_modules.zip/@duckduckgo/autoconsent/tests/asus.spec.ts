import generateCMPTests from "../playwright/runner";

generateCMPTests('asus', [
    'https://www.asus.com/',
]);