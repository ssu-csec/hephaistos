import generateCMPTests from "../playwright/runner";

generateCMPTests('Complianz banner', [
    'http://v3.oann.com/',
    'https://bloodpressureok.com/',
    'https://www.fussball-wm.pro/',
    'https://biselliano.info/',
], {}
);
