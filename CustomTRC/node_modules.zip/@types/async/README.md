# Installation
> `npm install --save @types/async`

# Summary
This package contains type definitions for Async ( https://github.com/caolan/async ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/async

Additional Details
 * Last updated: Wed, 08 May 2019 18:19:21 GMT
 * Dependencies: none
 * Global values: async

# Credits
These definitions were written by Boris Yankov <https://github.com/borisyankov>, Arseniy Maximov <https://github.com/kern0>, Joe Herman <https://github.com/Penryn>, Angus Fenying <https://github.com/fenying>, Pascal Martin <https://github.com/pascalmartin>, Dmitri Trofimov <https://github.com/Dmitri1337>.
