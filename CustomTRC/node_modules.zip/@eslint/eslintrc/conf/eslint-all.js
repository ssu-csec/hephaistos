/**
 * @fileoverview Stub eslint:all config
 * @author Nicholas C. Zakas
 */

"use strict";

module.exports = {
    settings: {
        "eslint:all": true
    }
};
